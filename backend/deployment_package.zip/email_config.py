import os
import pytz

EMAIL_USER ='naoresponda@pvtechsolutions.com.br'
EMAIL_PASSWORD ='#A8Trw6Fc'
EMAIL_RECEIVER ='contato@pvtechsolutions.com.br'
SMTP_SERVER ='mailserver.mixdinternet.com.br'
SMTP_PORT =587

EMAIL_SUBJECT = "Leads Site"

# --- Configuração de Fuso Horário (Brasil - São Paulo) ---
BRAZIL_TIMEZONE = pytz.timezone('America/Sao_Paulo')

